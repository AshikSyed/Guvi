package com.owner;

import java.sql.*;

import com.hostel.ConnectionManager;

public class OwnerDao {
	
	public static boolean isValid(String username,String password, String logType)
	{
		boolean isValid = false;
		Connection con = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		try{
		stmt = con.prepareStatement("select * from T_XBBNHGK_CREDENTIALS where LOGIN_ID = ? AND LOGIN_PWD = ? AND LOGIN_TYPE = ?");
		stmt.setString(1, username);
		stmt.setString(2, password);
		stmt.setString(3, logType);
		ResultSet rs = stmt.executeQuery();
		if(rs.next())
		{
			isValid = true;
		}
		}
		catch(SQLException e)
		{
			
		}
		return isValid;
	}
	
	public static void insertOwner(OwnerBean ownerbean)
	{
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = null;
		try
		{
			pstmt = con.prepareStatement("INSERT INTO T_XBBNHGK_OWNER_DETAILS VALUES(?,?,?,?)");
			pstmt.setString(1, ownerbean.getOwnerName());
			pstmt.setString(2, ownerbean.getOwnerPhoneNumber());
			pstmt.setString(3, ownerbean.getAddress());
			pstmt.setString(4, ownerbean.getOwnerID());
			pstmt.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}

}
