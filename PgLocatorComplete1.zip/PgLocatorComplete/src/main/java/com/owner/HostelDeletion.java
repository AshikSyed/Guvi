package com.owner;

import java.io.*;
import java.sql.*;

import com.hostel.ConnectionManager;


public class HostelDeletion {
	
	public static void deleteHostel(int id)
	{
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = null;
		try {
			
			//Deleting the hostel from facilities table
			pstmt = con.prepareStatement("DELETE FROM T_XBBNHGK_ROOM_FACILITIES WHERE ACC_ID = ?");
			pstmt.setInt(1, id);
			pstmt.executeUpdate();
			
			//Deleting the hostel from bills table
			pstmt = con.prepareStatement("DELETE FROM T_XBBNHGK_ACCOMODATION_BILLS WHERE ACC_ID = ?");
			pstmt.setInt(1, id);
			pstmt.executeUpdate();
			
			
			//Deleting from parent table
			pstmt = con.prepareStatement("DELETE FROM T_XBBNHGK_ACCOMODATION_DETAIL WHERE ACC_ID = ?");
			pstmt.setInt(1, id);
			pstmt.executeUpdate();	
			
			//Deleting the feedback
			pstmt = con.prepareStatement("DELETE FROM T_XBBNHGK_FEEDBACK_LIST WHERE ACC_ID = ?");
			pstmt.setInt(1, id);
			pstmt.executeUpdate();
			}
		 catch (SQLException e) {
			e.printStackTrace();
		}
		
		
	}

}
