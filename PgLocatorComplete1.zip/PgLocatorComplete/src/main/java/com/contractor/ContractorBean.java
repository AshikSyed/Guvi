package com.contractor;

public class ContractorBean {
	
	private String contractorId;
	private String contractorPwd;
	private int hostelID;
	private int rating;
	private String feedback;
	
	public int getHostelID() {
		return hostelID;
	}
	public void setHostelID(int hostelID) {
		this.hostelID = hostelID;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public String getContractorId() {
		return contractorId;
	}
	public void setContractorId(String contractorId) {
		this.contractorId = contractorId;
	}
	public String getContractorPwd() {
		return contractorPwd;
	}
	public void setContractorPwd(String contractorPwd) {
		this.contractorPwd = contractorPwd;
	}
	
	
	
}
