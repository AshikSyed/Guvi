package com.contractor;

import java.sql.*;

import java.util.*;

import org.apache.log4j.Logger;

import com.hostel.*;

public class ContractorDao {

	final static Logger logger = Logger.getLogger(ContractorDao.class);
	
	public static int insertContractor(String username,String password) 
	{
		//do not change
		String type = "CONT";
		int done_insertion = 0;
		PreparedStatement pstmt = null;
		logger.info("Inside Insert Contractor method");
		Connection con = ConnectionManager.getConnection();
		try{
		pstmt = con.prepareStatement("INSERT INTO T_XBBNHGK_CREDENTIALS VALUES(?,?,?)");
		pstmt.setString(1, username);
		pstmt.setString(2, password);
		pstmt.setString(3, type);
		
		done_insertion = pstmt.executeUpdate();
		
		
		if(done_insertion == 1)
		{
			done_insertion = 1;
		}
		}
		catch(SQLException e)
		{
			done_insertion = 100;
		}
		System.out.println(done_insertion);
		return done_insertion;
	}
	
	public static List retriveHostelAwaitingFeedback()
	{
		List hostelList = new ArrayList<HostelBean>();
		try {
			hostelList = HostelDao.getHostelForFeedback();
		} catch (Exception e) {
			e.printStackTrace();
		}	
		logger.info("Retrieving the Hostels awaiting feedback List" + hostelList.isEmpty());
		
		return hostelList;
	}
	
	public static int updateFeedback(ContractorBean cBean) {
		Connection conn = ConnectionManager.getConnection();
		int done = 0;
		PreparedStatement ps = null;
		logger.info("Inside contractordao update feedback method : HostelID:" + cBean.getHostelID() + " \nRating:" + cBean.getRating() + " \nFeedback"+ cBean.getFeedback());
		String updateQuery = "UPDATE T_XBBNHGK_ACCOMODATION_DETAIL SET ACC_RATING = ? , ACC_FEEDBACK = ? WHERE ACC_ID = ?";
		try {
			ps = conn.prepareStatement(updateQuery);
			ps.setInt(1, cBean.getRating());
			ps.setString(2, cBean.getFeedback());
			ps.setInt(3, cBean.getHostelID());
			done = ps.executeUpdate();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		String insertQuery = "INSERT INTO T_XBBNHGK_FEEDBACK_LIST VALUES(?,?,?)";
		try {
			ps = conn.prepareStatement(insertQuery);
			ps.setInt(1, cBean.getHostelID());
			ps.setInt(2, cBean.getRating());
			ps.setString(3, cBean.getFeedback());
			done = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println(done);
		return done;
	}
}
