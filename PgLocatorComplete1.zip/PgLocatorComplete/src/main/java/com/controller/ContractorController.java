package com.controller;

import com.contractor.*;
import com.feedback.*;
import com.hostel.HostelDao;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;





@RestController
@RequestMapping(value = "/contractor")
public class ContractorController {
	
	@Autowired
	FeedbackDao feedbackdao;
	
	final static Logger logger = Logger.getLogger(ContractorController.class);
	
	@RequestMapping(value = "/update", method = RequestMethod.PUT)
	public String updateHostel(@RequestBody ContractorBean cbean) throws Exception {
		logger.info("Inside the Updation Controller of contractor");
		int doneInsertion = 0;
		logger.info("Rating passed " + cbean.getRating() + " " + cbean.getContractorId() + cbean.getFeedback());
	    doneInsertion = ContractorDao.updateFeedback(cbean);
	    String res = "Not updated";
	    if(doneInsertion == 1)
	    {
	    	res = "Updated Successfully";
	    }
		return res;
	}
	
	
	
	@RequestMapping(value = "/feedback/{accID}", method = RequestMethod.GET)
	public List<FeedbackBean> getFeedback(@PathVariable("accID") int id) {
		logger.info("Inside the retrieval area of feedbacks");
		List<FeedbackBean> feedbackList = feedbackdao.getAllFeedback(id);
		return feedbackList;
	}
}
