package com.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.api.model.*;
import com.hostel.HostelBean;
import com.hostel.HostelDao;

@RestController
@RequestMapping(value = "/hostels")
public class HostelController {

	@Autowired
	HostelDao hosteldao;

	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public List getAllHostels() throws Exception {
		List<HostelBean> hostelList = hosteldao.getAllHostels();
		return hostelList;
	}

	@RequestMapping(value = "/delete/{accID}", method = RequestMethod.DELETE)
	public @ResponseBody String deletehostel(@PathVariable("accID") int id) throws Exception {
		System.out.println("Delete Method");
		String result = hosteldao.deleteHostel(id);
		return result;
	}

	@RequestMapping(value = "/addHostel", method = RequestMethod.POST)
	public String addHostel(@RequestBody HostelBean hbean) {
		int result = 0;
		String doneinset = "";
		HostelDao hdao = new HostelDao();
		result = hdao.registerHostel(hbean);
		if (result >= 1) {
			doneinset = "Hostel Inserted successfully";
		} else {
			doneinset = "Cannot Insert because you have a duplicate key";
		}
		return doneinset;
	}

	@RequestMapping(value = "/tophostel", method = RequestMethod.GET)
	public List getTopHostels() {
		List hostelList = new ArrayList<HostelBean>();
		try {
			hostelList = hosteldao.getTopHostels();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return hostelList;
	}

}
