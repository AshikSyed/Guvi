package com.login.credits;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

import com.hostel.ConnectionManager;

public class CreditsDao {

	public static int insertCredits(CreditsBean cb)
	{
		PreparedStatement pstmt = null;
		Connection con = ConnectionManager.getConnection();
		int doneInsertion = 0;
		try
		{
			pstmt = con.prepareStatement("INSERT INTO T_XBBNHGK_CREDENTIALS VALUES(?,?,?)");
			pstmt.setString(1, cb.getLoginID());
			pstmt.setString(2, cb.getLoginPassword());
			pstmt.setString(3, cb.getLoginType());
			doneInsertion = pstmt.executeUpdate();
		}
		
		catch(SQLException e)
		{
			doneInsertion = 100;
			
		}
		return doneInsertion;
	}
	
}
