package com.loginvalidator;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.hostel.ConnectionManager;

public class LoginValidator {
	
	public static boolean isValid(String username,String password, String acctype) throws SQLException
	{
		
		Connection con = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		System.out.println("Inside validating function");
			stmt = con.prepareStatement("select * from T_XBBNHGK_CREDENTIALS where LOGIN_ID = ? AND LOGIN_PWD = ? AND LOGIN_TYPE = ?");
			stmt.setString(1, username);
			stmt.setString(2, password);
			stmt.setString(3, acctype);
		boolean isValid = false;
		ResultSet rs = null;
		
		rs = stmt.executeQuery();
		System.out.println("values passed: " + username + " " + password + " " + acctype);
		while(rs.next())
		{
			System.out.println(rs.getString(1) + " " + rs.getString(2) + " " + rs.getString(3));
			isValid = true;
			System.out.println("Match Found");
		}
		
		System.out.println("Exiting the validation function!");
		return isValid;
		
	}

}
