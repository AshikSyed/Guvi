package com.mapper.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.hostel.HostelBean;

public class HostelRowMapper implements RowMapper<HostelBean> {

	public HostelBean mapRow(ResultSet rs, int rownum) throws SQLException {

		HostelBean hbean = new HostelBean();
		hbean.setHostelID(rs.getInt(1));
		hbean.setHostelName(rs.getString(2));
		hbean.setHostelAddress(rs.getString(3));
		hbean.setHostelLocation(rs.getString(4));
		hbean.setHostelRating(rs.getInt(5));
		hbean.setHostelFeedback(rs.getString(6));
		hbean.setRoomHasWifi(rs.getString(8));
		hbean.setRoomHasTV(rs.getString(9));
		hbean.setRoomHasFood(rs.getString(10));
		hbean.setRoomHasFurnished(rs.getString(11));
		hbean.setRoomHasAttachedToilet(rs.getString(12));
		hbean.setRoomHasSingleOccupancy(rs.getString(13));
		hbean.setRoomHasSharedOccupancy(rs.getString(14));
		hbean.setRoomHasRefrigerator(rs.getString(15));
		hbean.setRoomHasSecurity(rs.getString(16));
		hbean.setRoomHasWashingMachine(rs.getString(17));
		hbean.setRoomHasCupboard(rs.getString(18));
		hbean.setRoomHasVacant(rs.getString(19));
		hbean.setRoomNoOfCotsVacant(rs.getInt(20));
		hbean.setRoomMaxCapacity(rs.getInt(21));
		hbean.setRoomRent(rs.getString(22));
		hbean.setRoomWaterBill(rs.getString(23));
		hbean.setRoomCurrentBill(rs.getString(24));
		hbean.setRoomAdvance(rs.getString(25));
		return hbean;

	}

}
