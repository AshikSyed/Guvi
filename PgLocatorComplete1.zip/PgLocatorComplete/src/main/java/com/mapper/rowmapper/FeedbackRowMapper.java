package com.mapper.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.feedback.FeedbackBean;

public class FeedbackRowMapper implements RowMapper<FeedbackBean>{

	public FeedbackBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		FeedbackBean fbean = new FeedbackBean();
		fbean.setHostelID(rs.getInt(1));
		fbean.setRating(rs.getInt(2));
		fbean.setFeedback(rs.getString(3));		
		return fbean;
	}
}
