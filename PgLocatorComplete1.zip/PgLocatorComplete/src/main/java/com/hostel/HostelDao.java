package com.hostel;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.mapper.rowmapper.HostelRowMapper;



      

@Component
public class HostelDao extends JdbcDaoSupport{
	
	
	final static Logger logger = Logger.getLogger(HostelDao.class);
	
	 @Autowired
     public HostelDao(DataSource datasource) {
            // TODO Auto-generated constructor stub
            System.out.print("inside Dao with datasource object");
            if(datasource == null)
            {
            	logger.info("Datasorce is null");
            }
            setDataSource(datasource);
     }
	 
	
     public HostelDao() {
            // TODO Auto-generated constructor stub
    	 logger.info("Inside Non parameterized Constructor");
    
     }
     
     public List<HostelBean> getAllHostels() throws Exception {
    	 List<HostelBean> hostelList = getJdbcTemplate().query("SELECT * FROM T_XBBNHGK_ACCOMODATION_DETAIL NATURAL JOIN T_XBBNHGK_ROOM_FACILITIES NATURAL JOIN T_XBBNHGK_ACCOMODATION_BILLS", new Object[] {}, new HostelRowMapper());
         return hostelList;
     }
	
	
	
	
	public List getTopHostels() throws Exception {
		 List<HostelBean> hostelList = getJdbcTemplate().query("SELECT * FROM T_XBBNHGK_ACCOMODATION_DETAIL NATURAL JOIN T_XBBNHGK_ROOM_FACILITIES NATURAL JOIN T_XBBNHGK_ACCOMODATION_BILLS ORDER BY ACC_RATING DESC,RENT ASC,ADVANCEPAYMENT ASC,WATERBILL ASC,CURRENTBILL ASC FETCH FIRST 3 ROWS ONLY", new Object[] {}, new HostelRowMapper());
         return hostelList;
	}
	
	
	public static List getSpecHostels(int hid) throws SQLException {
		Connection con = ConnectionManager.getConnection();
		PreparedStatement stmt = con.prepareStatement("SELECT * FROM T_XBBNHGK_ACCOMODATION_DETAIL NATURAL JOIN T_XBBNHGK_ROOM_FACILITIES NATURAL JOIN T_XBBNHGK_ACCOMODATION_BILLS where ACC_ID = ?");
		stmt.setInt(1, hid);
		ResultSet rs = stmt.executeQuery();
		List<HostelBean> hostelList = new ArrayList<HostelBean>();
		
		
		while (rs.next()) {
			HostelBean temp = new HostelBean();
			temp.setHostelID(rs.getInt(1));
			temp.setHostelName(rs.getString(2));
			temp.setHostelAddress(rs.getString(3));
			temp.setHostelLocation(rs.getString(4));
			temp.setHostelRating(rs.getInt(5));
			temp.setHostelFeedback(rs.getString(6));
		
			temp.setRoomHasWifi(rs.getString(8));
			temp.setRoomHasTV(rs.getString(9));
			temp.setRoomHasFood(rs.getString(10));
			temp.setRoomHasFurnished(rs.getString(11));
			temp.setRoomHasAttachedToilet(rs.getString(12));
			temp.setRoomHasSingleOccupancy(rs.getString(13));
			temp.setRoomHasSharedOccupancy(rs.getString(14));
			temp.setRoomHasRefrigerator(rs.getString(15));
			temp.setRoomHasSecurity(rs.getString(16));
			temp.setRoomHasWashingMachine(rs.getString(17));
			temp.setRoomHasCupboard(rs.getString(18));
			temp.setRoomHasVacant(rs.getString(19));
			temp.setRoomNoOfCotsVacant(rs.getInt(20));
			temp.setRoomMaxCapacity(rs.getInt(21));
			temp.setRoomRent(rs.getString(22));
			temp.setRoomWaterBill(rs.getString(23));
			temp.setRoomCurrentBill(rs.getString(24));
			temp.setRoomAdvance(rs.getString(25));
			hostelList.add(temp);
		}
		return hostelList;
	}
	
	public static List getHostelForFeedback() throws Exception {
		Connection con = ConnectionManager.getConnection();
		Statement stmt = con.createStatement();
		List<HostelBean> hostelList = new ArrayList<HostelBean>();
		String searchQuery = "SELECT * FROM T_XBBNHGK_ACCOMODATION_DETAIL WHERE ACC_RATING = 0";
		ResultSet rs = stmt.executeQuery(searchQuery);
		while (rs.next()) {
			HostelBean temp = new HostelBean();
			temp.setHostelID(rs.getInt(1));
			temp.setHostelName(rs.getString(2));
			temp.setHostelAddress(rs.getString(3));
			temp.setHostelLocation(rs.getString(4));
			temp.setHostelRating(rs.getInt(5));
			temp.setHostelFeedback(rs.getString(6));
			hostelList.add(temp);
		}
		
			
	return hostelList;	
	}
	
	
	
	public String deleteHostel(int id)
	{
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = null;
		int i = 0;
		try {
			
			//Deleting the hostel from facilities table
			pstmt = con.prepareStatement("DELETE FROM T_XBBNHGK_ROOM_FACILITIES WHERE ACC_ID = ?");
			pstmt.setInt(1, id);
			 i = pstmt.executeUpdate();
			
			//Deleting the hostel from bills table
			pstmt = con.prepareStatement("DELETE FROM T_XBBNHGK_ACCOMODATION_BILLS WHERE ACC_ID = ?");
			pstmt.setInt(1, id);
			i  =  i + pstmt.executeUpdate();
			
			
			//Deleting from parent table
			pstmt = con.prepareStatement("DELETE FROM T_XBBNHGK_ACCOMODATION_DETAIL WHERE ACC_ID = ?");
			pstmt.setInt(1, id);
			i = i + pstmt.executeUpdate();	
			
			//Deleting the feedback
			pstmt = con.prepareStatement("DELETE FROM T_XBBNHGK_FEEDBACK_LIST WHERE ACC_ID = ?");
			pstmt.setInt(1, id);
			i = i + pstmt.executeUpdate();
			}
		
		 catch (SQLException e) {
			e.printStackTrace();
		}
		
		String result = "Delete Unsuccessful";
		if(i >= 1)
		{
			result = "Deleted Successfully";
		}
		
		return result;
		
	}
	
	public int registerHostel(HostelBean hBean)  {
		int doneInsert = 0;
		Connection conn = ConnectionManager.getConnection();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		PreparedStatement ps = null;

		if (hBean.getHostelID() != 0 && hBean.getRoomHasCupboard() != null) {
			String insertQuery = "insert into T_XBBNHGK_ACCOMODATION_DETAIL values(?,?,?,?,?,?,?)";

			try {
				ps = conn.prepareStatement(insertQuery);
				ps.setInt(1, hBean.getHostelID());
				ps.setString(2, hBean.getHostelName());
				ps.setString(3, hBean.getHostelAddress());
				ps.setString(4, hBean.getHostelLocation());
				ps.setInt(5, 0);
				ps.setString(6, "NULL");
				ps.setString(7, hBean.getOwnerID());
				doneInsert = ps.executeUpdate();
				
			}

			catch (Exception e) {
				logger.info("Duplicate key");
				return -1;
			}

			logger.info("No Duplicate Found");
			hBean.setRoomHasVacant((hBean.getRoomNoOfCotsVacant() <= 0 ? "NO" : "YES"));
			String insertQuery2 = "INSERT INTO T_XBBNHGK_ROOM_FACILITIES VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			try {
				ps = conn.prepareStatement(insertQuery2);
				ps.setInt(1, hBean.getHostelID());
				ps.setString(2, hBean.getRoomHasWifi());
				ps.setString(3, hBean.getRoomHasTV());
				ps.setString(4, hBean.getRoomHasFood());
				ps.setString(5, hBean.getRoomHasFurnished());
				ps.setString(6, hBean.getRoomHasAttachedToilet());
				ps.setString(7, hBean.getRoomHasSingleOccupancy());
				ps.setString(8, hBean.getRoomHasSharedOccupancy());
				ps.setString(9, hBean.getRoomHasRefrigerator());
				ps.setString(10, hBean.getRoomHasSecurity());
				ps.setString(11, hBean.getRoomHasWashingMachine());
				ps.setString(12, hBean.getRoomHasCupboard());
				if (hBean.getRoomMaxCapacity() - (hBean.getRoomMaxCapacity() - hBean.getRoomNoOfCotsVacant()) > 0) {
					hBean.setRoomHasVacant("YES");
				} else {
					hBean.setRoomHasVacant("NO");
				}
				ps.setString(13, hBean.getRoomHasVacant());
				ps.setInt(14, hBean.getRoomNoOfCotsVacant());
				ps.setInt(15, hBean.getRoomMaxCapacity());
				
				doneInsert = doneInsert + ps.executeUpdate();
				
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else {
			logger.info("Error occured while inserting");
		}

		String insertQuery3 = "INSERT INTO T_XBBNHGK_ACCOMODATION_BILLS VALUES(?,?,?,?,?)";
		try {
			ps = conn.prepareStatement(insertQuery3);
			ps.setInt(1, hBean.getHostelID());
			ps.setString(2, hBean.getRoomRent());
			ps.setString(3, hBean.getRoomWaterBill());
			ps.setString(4, hBean.getRoomCurrentBill());
			ps.setString(5, hBean.getRoomAdvance());
			doneInsert = doneInsert + ps.executeUpdate();
		
		} catch (SQLException e) {
			e.printStackTrace();
		}
			return doneInsert;
	}

	
}