package com.tenant;
import java.io.*;
import java.sql.*;

import com.hostel.ConnectionManager;
import com.login.credits.CreditsDao;

public class TenantDao {
	
	
	
	public static void insertTenant(TenantBean tbean)
	{
		int success = 0;
		try{
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = con.prepareStatement("INSERT INTO T_XBBNHGK_TENANT VALUES(?,?,?,?,?)");
		pstmt.setString(1, tbean.getTenantID());
		pstmt.setString(2, tbean.getTenantName());
		pstmt.setString(3, (tbean.getTenantPhoneNo()));
		pstmt.setString(4, tbean.getEmail());
		pstmt.setInt(5, 0);
		success = pstmt.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
	
	public static int giveRequestForHostel(TenantBean tbean)
	{
		
		int success = 0;
		try{
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = con.prepareStatement("INSERT INTO T_XBBNHGK_REQUEST_HOUSE VALUES(?,?,?,?,?)");
		pstmt.setInt(1,tbean.getAcc_id());
		pstmt.setString(2, tbean.getTenantID());
		pstmt.setString(3, tbean.getTenantName());
		pstmt.setString(4, tbean.getTenantPhoneNo());
		pstmt.setString(5, tbean.getEmail());
		
		success = pstmt.executeUpdate();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return success;
	}
	
	public static TenantBean retreiveDetail(String id) throws SQLException
	{
		TenantBean tbean = new TenantBean();
		int success = 0;
		ResultSet rs = null;
		try{
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = con.prepareStatement("SELECT * FROM T_XBBNHGK_TENANT WHERE TEN_ID = ?");
		pstmt.setString(1, id);
		rs = pstmt.executeQuery();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		while(rs.next())
		{
			tbean.setTenantID(rs.getString(1));
			tbean.setTenantName(rs.getString(2));
			tbean.setTenantPhoneNo(rs.getString(3));
			tbean.setEmail(rs.getString(4));
			tbean.setAcc_id(rs.getInt(5));
		}
		
		return tbean;
	}
	
	public static void reqdelete(String ID) throws SQLException
	{
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = con.prepareStatement("DELETE FROM T_XBBNHGK_REQUEST_HOUSE WHERE TENANT_ID = ?");
		pstmt.setString(1, ID);
		int i = pstmt.executeUpdate();
		
	
	}
	
		
	public static void insertRequestStatus(String tenantID) throws SQLException
	{
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = con.prepareStatement("INSERT INTO T_XBBNHGK_REQUEST_STATUS VALUES(?,?)");
		pstmt.setString(1, tenantID);
		pstmt.setString(2, "NOT ALLOCATED");
		int i = pstmt.executeUpdate();
		System.out.print(i);
	}

}
