package com.tenant;

public class TenantBean {
	
	//TENANT INFORMATION
		
		private String tenantName;
		private String tenantPhoneNo;
		private String email;
		private int acc_id;
		private String tenantID;
		private String tenantPassword;
		
		
		public String getTenantPassword() {
			return tenantPassword;
		}
		public void setTenantPassword(String tenantPassword) {
			this.tenantPassword = tenantPassword;
		}
		public String getTenantID() {
			return tenantID;
		}
		public void setTenantID(String tenantID) {
			this.tenantID = tenantID;
		}
		public String getTenantName() {
			return tenantName;
		}
		public void setTenantName(String tenantName) {
			this.tenantName = tenantName;
		}
		public String getTenantPhoneNo() {
			return tenantPhoneNo;
		}
		public void setTenantPhoneNo(String tenantPhoneNo) {
			this.tenantPhoneNo = tenantPhoneNo;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public int getAcc_id() {
			return acc_id;
		}
		public void setAcc_id(int acc_id) {
			this.acc_id = acc_id;
		}
		
}
