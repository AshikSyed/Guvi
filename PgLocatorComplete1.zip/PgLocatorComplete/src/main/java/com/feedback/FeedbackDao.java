package com.feedback;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.mapper.rowmapper.FeedbackRowMapper;
import com.mapper.rowmapper.HostelRowMapper;

@Component
public class FeedbackDao extends JdbcDaoSupport{
	

	@Autowired
    public FeedbackDao(DataSource datasource) {
           // TODO Auto-generated constructor stub
           System.out.print("inside Dao with datasource object");
           if(datasource == null)
           {
           	System.out.println("Datasorce is null");
           }
           setDataSource(datasource);
    }
	 
	
    public FeedbackDao() {
           // TODO Auto-generated constructor stub
           System.out.print("inside dao cons");
   
    }
	
	public List<FeedbackBean> getAllFeedback(int id)
	{
		String sql = "SELECT * FROM T_XBBNHGK_FEEDBACK_LIST WHERE ACC_ID = " + id;
		List<FeedbackBean> feedbacklist = getJdbcTemplate().query(sql,new Object[]{}, new FeedbackRowMapper());
		return feedbacklist;
	}

}
