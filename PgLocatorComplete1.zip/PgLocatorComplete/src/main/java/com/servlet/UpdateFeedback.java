package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.FileSystemResource;

import com.contractor.ContractorBean;
import com.contractor.ContractorDao;
import com.controller.ContractorController;

public class UpdateFeedback extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public UpdateFeedback() {
        super();

    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			updateFeedback(request,response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private void updateFeedback(HttpServletRequest request, HttpServletResponse response) throws Exception {
		response.setContentType("text/html");
		

		BeanFactory factory = new XmlBeanFactory(new FileSystemResource("C:\\Users\\XBBNHGK\\Desktop\\Pg Locator Complete\\PgLocatorComplete\\src\\main\\webapp\\WEB-INF\\spring-servlet.xml"));
        DataSource obj = (DataSource) factory.getBean("dataSource"); 
        
        
		PrintWriter out = response.getWriter();
		ContractorBean contractorBean = new ContractorBean();
		contractorBean.setHostelID((Integer.parseInt(request.getParameter("hostelID"))));
		contractorBean.setRating(Integer.parseInt(request.getParameter("rating")));
		contractorBean.setFeedback(request.getParameter("feedback"));
		
        
		ContractorController conController = new ContractorController();
		System.out.print(conController.updateHostel(contractorBean));
		out.print("<script type=\"text/javascript\">");
		out.print("alert('Updated Successfully');");
		out.println("location='contractor2.jsp';");
		out.print("</script>");
				
	}

}
