package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.contractor.ContractorDao;

public class AddContractor extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		int doneInsertion = 0;
		PrintWriter out = response.getWriter();
		String n = request.getParameter("username");
		String p = request.getParameter("password");
		int otp = 0;
		try {
			otp = Integer.parseInt(request.getParameter("otpnum"));
		} catch (NumberFormatException e) {
			otp = 0;
		}
		if (otp == 123) {
			doneInsertion = ContractorDao.insertContractor(n, p);
		}
		System.out.println("Insertion: " + doneInsertion);
		if ((doneInsertion == 1)) {
			out.println("<html><body onload=\"alert('Registration Successfully Done!!!')\"></body></html>");
			RequestDispatcher rs = request.getRequestDispatcher("index.jsp");
			rs.include(request, response);
		} else if (doneInsertion == 100) {
			out.println(
					"<html><body onload=\"alert('Username is already taken. Please Enter different Username')\"></body></html>");
			RequestDispatcher rs = request.getRequestDispatcher("index.jsp");
			rs.include(request, response);
		} else {
			out.println("<html><body onload=\"alert('Invalid OTP.Try again with correct OTP')\"></body></html>");
			RequestDispatcher rs = request.getRequestDispatcher("index.jsp");
			rs.include(request, response);
		}
		
	}

}
