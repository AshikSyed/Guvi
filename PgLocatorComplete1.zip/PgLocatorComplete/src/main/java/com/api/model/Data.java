package com.api.model;
import java.util.List;

public class Data {



	
	
	private List<Test> output;
	
	
	public List<Test>  getOutput() {
		return output;
	}
	public void setOutput(List<Test> outputList) {
		this.output = outputList;
	}
	
	
}
