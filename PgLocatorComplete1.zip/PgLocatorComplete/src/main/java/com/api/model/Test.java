package com.api.model;

public class Test {
	
			private String testId;
	public String getTestCreatedTs() {
		return testCreatedTimeStamp;
	}
	public void setTestCreatedTs(String testCreatedTS) {
		this.testCreatedTimeStamp = testCreatedTimeStamp;
	}
	
	private String testName;
	public String getTestId() {
		return testId;
	}
	public void setTestId(String testId) {
		this.testId = testId;
	}
	
	public String getTestName() {
		return testName;
	}
	
	public void setTestName(String testName) {
		this.testName = testName;
	}

	
	public String getTestDuration() {
		return testDuration;
	}
	public void setTestDuration(String testDuration) {
		this.testDuration = testDuration;
	}
	
	public String getTestInstr() {
		return testInstr;
	}
	public void setTestInstr(String testInstr) {
		this.testInstr = testInstr;
	}
	public String getTestChargeBack() {
		return testChargeBack;
	}
	public void setTestChargeBack(String testChargeBack) {
		this.testChargeBack = testChargeBack;
	}

	private String testCreatedTimeStamp;

	private String testDuration;
	
	private String testInstr;
	
	private String testChargeBack;
	
	

}
