import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.loginvalidator.LoginValidator;

@SuppressWarnings("serial")
public class HouseOwnerValidation extends HttpServlet {

	ServletConfig config = null;

	public void init(ServletConfig config) {
		this.config = config;
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String n = request.getParameter("username2");
		String p = request.getParameter("password2");
		String a = "OWNER";
		System.out.println(n + " " + a + " " + p);
		boolean isValid = false;
		try {
			isValid = LoginValidator.isValid(n, p, a);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (isValid) {
			RequestDispatcher rd = request.getRequestDispatcher("houseowner1.html");
			rd.forward(request, response);
		} else {
			RequestDispatcher rd = request.getRequestDispatcher("index.html");
			rd.forward(request, response);
		}

	}

}
