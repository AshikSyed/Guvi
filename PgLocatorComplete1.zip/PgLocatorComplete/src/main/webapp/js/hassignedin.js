/**
 * 
 */

function hasSignedin()
{
	alert("Please signin to experience the full")
	
	return location.href('index.jsp')
}