function validateButton() {

	var x = document.getElementById("uname").value;

	var y = document.getElementById("psw").value;

	if ((x == null || x.length == 0 || x == undefined)
			&& (y == null || y.length == 0 || y == undefined)) {

		alert("Please Enter Name,Password");

		return false;

	} else {
		return true;
	}

}
