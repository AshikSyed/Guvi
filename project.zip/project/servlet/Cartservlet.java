

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import javax.servlet.http.HttpSession;

import com.inautix.training.shopping.dao.Cartdao;
import com.inautix.training.shopping.doamin.Customer;

/**
 * Servlet implementation class Cartservlet
 */
@WebServlet("/Cartservlet")
public class Cartservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Cartservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 HttpSession session=request.getSession();
		 String sn=(String)session.getAttribute("name");
		 String productname=request.getParameter("p");
		 int price=(Integer)session.getAttribute("cpp");
		 int qty=Integer.parseInt(request.getParameter("q"));
		 Customer cus = new Customer();
			 cus.setCustomername(sn);
			 cus.setProductname(productname);
			 cus.setPrice(price);
			 cus.setQty(qty);
			 Cartdao cd=new Cartdao();
			 cd.createcustomer(cus);
			 response.setContentType("text/html");
			 response.sendRedirect("cart.jsp");
	}

}
