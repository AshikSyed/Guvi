

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.training.shopping.controller.ossystem;
import com.inautix.training.shopping.dao.Adminver;
import com.inautix.training.shopping.doamin.Customer;

/**
 * Servlet implementation class Adminservlet
 */
@WebServlet("/Adminservlet")
public class Adminservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Adminservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 response.setContentType("text/html");  
	        PrintWriter out=response.getWriter();  
	        
	          
	        String name1=request.getParameter("name");  
	        String password1=request.getParameter("password");  
	        Customer customer =new Customer();
			
			customer.setCustomername(name1);
			customer.setPassword(password1);
			System.out.println("insideservlet");
			System.out.println(name1);
			System.out.println(password1);
			Adminver v=new Adminver();
			
			 String status=v.verify(customer);
			
			 if(status.equals("yes"))
			 {
				 HttpSession session=request.getSession();
				 session.setAttribute("n", name1);
				 response.setContentType("text/html");
				 response.sendRedirect("addproduct.html");
			 }
			 else
			 {
				 System.out.println("invalid");
			 }
			
					
	}

}
