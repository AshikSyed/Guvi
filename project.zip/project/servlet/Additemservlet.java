

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.training.shopping.dao.Cartdao;
import com.inautix.training.shopping.dao.Itemdao;
import com.inautix.training.shopping.doamin.Customer;

/**
 * Servlet implementation class Additemservlet
 */
@WebServlet("/Additemservlet")
public class Additemservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Additemservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name=request.getParameter("name");
		int phoneno=Integer.parseInt(request.getParameter("phoneno"));
		int payment=Integer.parseInt(request.getParameter("payment"));
		String address=request.getParameter("address");
		System.out.println("name is"+name);
		System.out.println("phoneno is"+phoneno);
		System.out.println("paymnet is"+payment);
		System.out.println("address is"+address);
		Customer cus=new Customer(); 
		cus.setCustomername(name);
		cus.setPhoneno(phoneno);
		cus.setPayment(payment);
		cus.setAddress(address);
	Itemdao ido=new Itemdao();
ido.createcustomer(cus);
 RequestDispatcher rd = request.getRequestDispatcher("/final.html");

         rd.forward(request, response);

		
		
		

		
	}

}
