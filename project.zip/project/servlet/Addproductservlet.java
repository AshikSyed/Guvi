

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.inautix.training.shopping.dao.Addproductdao;
import com.inautix.training.shopping.doamin.Customer;

/**
 * Servlet implementation class Addproductservlet
 */
@WebServlet("/Addproductservlet")
public class Addproductservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Addproductservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name=request.getParameter("name");
		int price=Integer.parseInt(request.getParameter("price"));
	Customer cu = new Customer();
	cu.setProductname(name);
    cu.setPrice(price);
    Addproductdao ado=new Addproductdao();
    ado.createcustomer(cu);
    RequestDispatcher rd = request.getRequestDispatcher("adminfinal.html");
    rd.forward(request,response);
	}

}
