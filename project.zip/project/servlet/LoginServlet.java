


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.PrintWriter;

import javax.servlet.http.HttpSession;  

import com.inautix.training.shopping.controller.ossystem;
import com.inautix.training.shopping.doamin.Customer;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 response.setContentType("text/html");  
	        PrintWriter out=response.getWriter();  
	        
	          
	        String name=request.getParameter("name");  
	        String password=request.getParameter("password");  
	        Customer customer =new Customer();
			
			customer.setCustomername(name);
			customer.setPassword(password);
			ossystem oss = new ossystem();
			 String status=oss.verify(customer);
			 if(status.equals("yes"))
			 {
				 HttpSession session=request.getSession();
				 session.setAttribute("n", name);
				 response.setContentType("text/html");
				 response.sendRedirect("welcome.html");
			 }
			 else
			 {
				 System.out.println("invalid");
			 }
			
					
	       /* if(password.equals(pass)){  
	        
	        HttpSession session=request.getSession();  
	        session.setAttribute("name",name);  
	        out.write("welcome,"+name);
	        request.getRequestDispatcher("welcome.html").include(request, response);  
	        }  
	        else{  
	            out.write("Sorry, username or password error!");  
	            request.getRequestDispatcher("login.html").include(request, response);  
	        }  */
	        
	out.close();  
	}

}

