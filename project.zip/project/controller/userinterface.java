package com.inautix.training.shopping.controller;

public interface userinterface {
	public void login();
	public void payment();
	
	
	}

