package com.inautix.training.shopping.controller;

import com.inautix.training.shopping.dao.Customerdao;
import com.inautix.training.shopping.doamin.Customer;

public class Signupcontroller {
	public Signupcontroller(Customer c){
		Customerdao cd = new Customerdao();
		cd.createcustomer(c);
	}

}
