package com.inautix.training.shopping.controller;

import java.util.*;

import com.inautix.training.shopping.dao.Ver;
import com.inautix.training.shopping.dao.chechavailablity;
import com.inautix.training.shopping.doamin.Customer;
import com.inautix.training.shopping.dao.Customerdao;
public class ossystem {
	
	 chechavailablity ch = new  chechavailablity();
	 public List status(String p)
	 {
		 List l = ch.status(p);
		 return l;
	 }
	public void getCustomerDetails(Customer customer)
	{
		Customerdao cusdao= new Customerdao();
		cusdao.createcustomer(customer);
		
	}
	public String verify(Customer c1){
		Ver v=new Ver();
		String st=v.verify(c1);
		return st;
		
	}
	
}