package com.inautix.training.shopping.dao;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.inautix.training.shopping.doamin.Customer;
import com.inautix.training.shopping.doamin.Productlist;

public class Customerdao {
	
	public void createcustomer(Customer customer)
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
			System.out.println(e);
		}

		try {
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

			Statement stmt = con.createStatement();
			
String sql ="insert into Customers_201170 values ("+customer.getCusid()+",'"+customer.getCustomername()+"','"+customer.getPhoneno()+"')";
	

stmt.execute(sql);
String sql1="insert into detail_201170 values('"+customer.getCustomername()+"','"+customer.getPassword()+"')";	
stmt.execute(sql1);
			con.commit();
			con.close();
		System.out.println("Customer record inserted successfully");
		}
		catch(Exception e){
			
			
		}
		
	}
	public List getAllProductDetails(String productname) throws ClassNotFoundException, SQLException
    {
          Productlist p1= null;
           List list = new ArrayList();
           Class.forName("oracle.jdbc.driver.OracleDriver");
           Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
         String str="select * from product_201170";
         Statement stmt= con.createStatement();
         ResultSet rs= stmt.executeQuery(str);
         while(rs.next())
         {
            p1=new Productlist();
            p1.setProduct(rs.getString(1));
            p1.setPrice(rs.getInt(2));
           
            list.add(p1);
         }
         return list;
    }
	public Customer getProduct(String name) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		 Class.forName("oracle.jdbc.driver.OracleDriver");
         Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
      Customer cc=new Customer();
         String str="select * from product_201170 where productname='"+name+"'";
       Statement stmt= con.createStatement();
       ResultSet rs= stmt.executeQuery(str);
       String stn;
       int n;
       System.out.println(rs);
       while(rs.next()){
    	   System.out.println("inside while");
    	  stn=rs.getString("productname") ;
    	  System.out.println(stn);
    	  cc.setProductname(stn);
    	  n=rs.getInt("price");
    	  System.out.println(n);
    	  cc.setPrice(n);
    	  
    	  
       }
       
		
		return cc;
		
	}



}
