package com.inautix.training.shopping.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import com.inautix.training.shopping.doamin.Customer;

public class Itemdao {
	public void createcustomer(Customer customer)
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
			System.out.println(e);
		}

		try {
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

			Statement stmt = con.createStatement();
			
String sql ="insert into additem_201170 values ('"+customer.getCustomername()+"',"+customer.getPhoneno()+",'"+customer.getAddress()+"',"+customer.getPayment()+")";

	

stmt.executeQuery(sql);
		
			con.commit();
			con.close();
		System.out.println("Customer record inserted successfully1");
		}
		catch(Exception e){
			
			
		}
		
	}
}
