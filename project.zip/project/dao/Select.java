package com.inautix.training.shopping.dao;


import java.util.Scanner;



public class Select {
	Scanner sc=new Scanner(System.in);
	int n= sc.nextInt();
static int ff(int n)
{
	if(n==0)
	{
		return 1;
	}
	else
	{
		return n*ff(n-1);
	}
}
}


	
