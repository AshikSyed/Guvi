package com.inautix.training.shopping.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.inautix.training.shopping.doamin.Customer;

public class Customerdao2 {
	public Customer getProduct(String name) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		 Class.forName("oracle.jdbc.driver.OracleDriver");
         Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
      Customer cc=new Customer();
         String str="select * from product_201170 where productname='"+name+"'";
       Statement stmt= con.createStatement();
       ResultSet rs= stmt.executeQuery(str);
       String stn;
       int n;
       while(rs.next()){
    	  stn=rs.getString("productname") ;
    	  System.out.println(stn);
    	  cc.setProductname(stn);
    	  n=rs.getInt("price");
    	  System.out.println(n);
    	  cc.setPrice(n);
    	  
    	  
       }
       
		
		return cc;
		
	}



}



