package com.inautix.training.shopping.dao;
import com.inautix.training.shopping.doamin.*;
import com.inautix.training.shopping.controller.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

import com.inautix.training.shopping.exception.nostockexception;

public class chechavailablity {
	public List status(String p)
	{
		List a = new ArrayList();
		Customer c = new Customer();
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
			System.out.println(e);
		}

		try {
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");


			
			Statement stmt = con.createStatement();
			String sql="select * from product_xbbnhco where prod_name=?";
			
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,p);
			
			

			
			ResultSet rs = ps.executeQuery();

			
			while(rs.next()) {
				
				c.setSt(rs.getString("status"));
			}

		
			con.commit();
			con.close();

		}catch(SQLException e) {
			System.out.println(e);
			System.out.println(e.getMessage());
			System.out.println(e.getSQLState());
			System.out.println(e.getErrorCode());
			e = e.getNextException();
	}
		a.add(c);
		return a;
		
	}
	
	
}
