package com.inautix.training.shopping.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.inautix.training.shopping.doamin.Customer;

public class Adminver {
	public String verify(Customer c1){
		String name="";
		String p="";
		String sta="";

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
			System.out.println(e);
		}

		try {
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

			Statement stmt = con.createStatement();
			
	String sql ="select * from admin_201170 where username='"+c1.getCustomername()+"' and userpassword='"+c1.getPassword()+"'";
System.out.println(c1.getCustomername());
System.out.println(c1.getPassword());

	ResultSet rs=stmt.executeQuery(sql);
	System.out.println(rs);
		while(rs.next())
		{
			System.out.println(rs.getString("username"));
			sta="yes";
		}
			con.commit();
			con.close();
		System.out.println("Customer record inserted successfully");
		}
		catch(Exception e){
			
			
		}
		return sta;
		
	}


}
