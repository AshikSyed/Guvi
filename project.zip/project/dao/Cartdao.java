package com.inautix.training.shopping.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.inautix.training.shopping.doamin.Customer;

public class Cartdao {
	public void createcustomer(Customer customer)
	{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
			System.out.println(e);
		}

		try {
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

			Statement stmt = con.createStatement();
			
String sql ="insert into cart_201170 values ('"+customer.getCustomername()+"','"+customer.getProductname()+"',"+customer.getPrice()+","+customer.getQty()+")";
	

stmt.execute(sql);
		
			con.commit();
			con.close();
		System.out.println("Customer record inserted successfully");
		}
		catch(Exception e){
			
			
		}
		
	}
	public List view(Customer c)
	{
		List l=new ArrayList();
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(ClassNotFoundException e) {
			System.out.println(e);
		}

		try {
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

			Statement stmt = con.createStatement();
			
String sql ="select * from cart_201170 where username='"+c.getCustomername()+"'";
	

ResultSet rs=stmt.executeQuery(sql);
while(rs.next())
{
	c.setProductname(rs.getString("productname"));
	c.setPrice(rs.getInt("price"));
	l.add(c);
	
}
		
			con.commit();
			con.close();
		System.out.println("Customer record inserted successfully");
		}
		catch(Exception e){
			
			
		}
		return l;
	}


public void deletecustomer(Customer customer)
{
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
	}catch(ClassNotFoundException e) {
		System.out.println(e);
	}

	try {
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

		Statement stmt = con.createStatement();
		
String sql ="delete cart_201170 where username='"+customer.getCustomername()+"' and productname='"+customer.getProductname()+"'";
System.out.println(sql);
stmt.executeQuery(sql);
	
		con.commit();
		con.close();
	System.out.println("Customer record inserted successfully");
	}
	catch(Exception e){
		
		
	}
	
}
}

