package com.inautix.training.shopping.doamin;

public class Productlist {
private String product;
public String getProduct() {
	return product;
}
public void setProduct(String product) {
	this.product = product;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
private int price;

}
