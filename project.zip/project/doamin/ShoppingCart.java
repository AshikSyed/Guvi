package com.inautix.training.shopping.doamin;
import com.inautix.training.shopping.exception.*;
import com.inautix.training.shopping.dao.*;
public class ShoppingCart  {
	private int cartid;
	public int getCartid() {
		return cartid;
	}

	public void setCartid(int cartid) {
		this.cartid = cartid;
	}

	public int getProductid() {
		return productid;
		
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	private int productid;
	private int quantity;
	
	public void addcartitem() throws nostockexception
	{
		try
		{
			nostockexception n = new nostockexception();
			throw n;
		}
		catch(nostockexception n)
		{
			System.out.println("msg"+ n.notavilable());
		}
		
	}
}
	
