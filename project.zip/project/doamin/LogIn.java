package com.inautix.training.shopping.doamin;
import com.inautix.training.shopping.exception.*;
import com.inautix.training.shopping.dao.*;

public class LogIn {
	private String loginid;
	public String getLoginid() {
		return loginid;
	}
	public void setLoginid(String loginid) {
		this.loginid = loginid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	private String password;
	public void Verifylogin() throws nostockexception
	{
		try
		{
			nostockexception lo = new nostockexception();
				throw lo;
		}
		catch(nostockexception lo)
		{
			System.out.println("msg"+ lo.login());
		}
		
	}
	chechavailablity ck = new chechavailablity();

}
