package com.inautix.training.shopping.doamin;
import com.inautix.training.shopping.controller.*;
import java.util.*;

public class mainclass {
	public static void main(String args[]){
		ossystem os = new ossystem();
		Scanner scan = new Scanner(System.in);
		System.out.println("1.Admin  2.Customer");
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		switch(a)
		{
		case 1:
			
			
		{
		System.out.println("Eneter the customer id");
		int Cus_id=scan.nextInt();
		System.out.println("enter the customer name");
		String Cus_Name=scan.next();
		System.out.println("Enter customer phone number");
		int Cus_ph=scan.nextInt();
		Customer customer =new Customer();
		customer.setCusid(Cus_id);
		customer.setCustomername(Cus_Name);
		customer.setPhoneno(Cus_ph);
		os.getCustomerDetails(customer);
		/*List l1 = os.status(scan.nextLine());
		Iterator i = l1.iterator();
		while(i.hasNext())
		{
			Customer d = (Customer)i.next();
			System.out.println(d.getSt());
			
		}*/
		
		
		
		
	}
		
		case 2:{
			List l1 = os.status(scan.nextLine());
			Iterator i = l1.iterator();
			while(i.hasNext())
			{
				Customer d = (Customer)i.next();
				System.out.println(d.getSt());
				
			}
			
			
		}
			
	}
	}
}


  























               
  

 